export const EDITION = 'free';
